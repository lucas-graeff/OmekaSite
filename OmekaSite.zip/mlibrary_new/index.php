<?php 

  add_filter('theme_options', function ($options, $args) {
    return serialize(
      ['display_header' => '1'] +
      unserialize(exhibit_builder_theme_options($options, $args))
    );
  });

	echo head(array('bodyid'=>'home')); 
?>

<div class="row">
    <div class="col-xs-12">
    <div class="row detail-nav">
    	<div class="col-xs-12 ">
    		<div class="col-xs-12 col-sm-6">
    			<ul>
    			<li class="detail-nav-heading" style="font-weight: bold;">Browse Digital Exhibits</li>
    			<li>Explore and discover inspiring collections of art, literature, culture, and history.</li>
    			<li><a href="<?php echo url('exhibits'); ?>">Browse digital exhibits</a></li>
    			</ul>
	    	</div>
	    	<div class="col-xs-12 col-sm-6">
	    		<ul>
    			<li class="detail-nav-heading" style="font-weight: bold;">Digital Exhibits at the University of North Florida</li>
    			<li>UNF library digital exhibits are created to highlight selected materials held by the Thomas G. Carpenter Library and Special
           Collections and University Archives.  Exhibits pull together items in support of particular themes.  Many of the materials are 
           also available and browsable by collection within the <a href="https://digitalcommons.unf.edu/">UNF Digital Commons</a></li>
    			</ul>
	    	</div>
    	</div>
    </div>
    <div class="col-xs-12 ">
      <div class="detail-nav-border"></div>
    </div>
    </div>

    <div class="col-xs-12">
      <h2 class="text-center">Featured Digital Exhibits</h2>
    </div>
    <div class="col-xs-12">	
        
        <?php echo mlibrary_new_exhibit_builder_display_random_featured_exhibit(); ?>           
     </div>
  
       <div class="col-xs-12 index-exhibits-container">
         <?php
           if (plugin_is_active('ExhibitBuilder') && function_exists('mlibrary_new_recent_exhibits_bootstrap')) { 
              echo mlibrary_new_recent_exhibits_bootstrap(6);
           }?>
       </div>

  </div>

    <div class="browse-index">
      <div class="button browse-btn"><a href="<?php echo url('exhibits'); ?>">See All Exhibits</a></div>
    </div>
    
</div>    
</div>

<?php fire_plugin_hook('public_home', array('view' => $this)); ?>

<?php echo foot(); ?>

