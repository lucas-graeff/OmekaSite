 <div>
<section>
  <!--Breadcrumb and Share Bar-->
 <div class="col-xs-12">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><?php echo link_to_home_page(__('Home')); ?></li>
        <li class="breadcrumb-item active">About Digital Exhibits</li>
      </ol>
  </div>
</section>

<section>
  <div class="col-xs-12 about-online-exhibits">

<h1>Digital Exhibits at the University of North Florida</h1>
                                        <p>UNF library digital exhibits are created to highlight selected materials held by the Thomas G. Carpenter Library and Special
                                         Collections and University Archives.  Exhibits pull together items in support of particular themes.  Many of the materials are 
                                         also available and browsable by collection within the <a href="https://digitalcommons.unf.edu/" >UNF Digital Commons</a> </p>

         <p>The Thomas G. Carpenter Library has placed copies of these works online for educational and research purposes only.  Works may be under copyright. If you use any of these works, you are responsible for making your own legal assessment and securing any necessary permissions.  

</p>

          <p class='about-contact'>If you have questions about an exhibit, please contact <a href="mailto:lib-digital@unf.edu">lib-digital@unf.edu</a>
                            </p>

</div>
</div>
</section> 
