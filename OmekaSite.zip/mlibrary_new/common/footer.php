	</div><!-- end content -->
</main>
	<footer class="site-footer" role="contentinfo">
    <div id=footerMain>
    <div id="footerAlign">
    <div id=mainBox1 class="mainBox">
            <div id="footerLogo">
                <img src="https://www.unf.edu/image/UNFLogoFooter.png" alt="University of North Florida Logo" />
            </div>
            <address id="footerContact">
                    <p class="dept" id="carpenter-library">Thomas G. Carpenter Library</p>
                    <div><p>1 UNF Drive</p><p>Jacksonville, FL 32224</p> <p>Phone: 904-620-2615</p> <p>Text: 904-507-4122</p></div>
                    <p></p>
                    
                       <p><a class="unbold" href="mailto:ask@unf.libanswers.com" >ask@unf.libanswers.com</a></p>
                     
                        <p><a class="unbold" href="https://www.google.com/maps/place/Thomas+G.+Carpenter+Library/@30.2692476,-81.5083946,15z/data=!4m2!3m1!1s0x0:0x2bedac61ada9b0f6?sa=X&ved=0ahUKEwjNp9KSmszbAhXO41MKHfqvCaMQ_BIIoQEwDQ">View Map</a></p>
                    
            </address>
    </div>
<div class="colDivFlat" id="topColDivFlat"></div>
    <div class="colDiv" id="firstColDiv"></div>
    <div id="mainBox2" class="mainBox">
<span id="today-hour"><h2 style="text-align: center;">Today's Hours</h2></span><!--Library Hours Information Begins--><p> </p><div style="text-align: right;" id="api_hours_today_iid928_lid0"> </div><script type="text/javascript" src="https://api3.libcal.com/api_hours_today.php?iid=928&lid=0&format=js&context=object"></script><p style="text-align: center;">
              <a class="unbold" href="https://libguides.unf.edu/hours">Library Hours</a>
            </p><p> </p> <p style="text-align: center;"><a class="unbold" href="http://unf.libcal.com/events">Event Calendar</a></p>
                    
    </div>
<div class="colDivFlat" id="secondColDivFlat"></div>
    <div class="colDiv"></div>
    <div id="mainBox3" class="mainBox">
            <a href="https://www.unf.edu/library/about/mission.aspx">
              <div id="library-vision">Library Vision</div>
            </a>
            <p>The Carpenter Library aspires to be the intellectual center of its community, to foster innovations that lead to the discovery of knowledge, and to further the research and scholarly endeavors of its users.</p><p> </p><p class="fineprint2" style="text-align: center; color: white;">
              </p>
    </div>
    <div class="colDiv"></div>
<div class="colDivFlat" id="thirdColDivFlat"></div>
    <div id="mainBox4" class="mainBox">
        <div id="social-media-images">
<div id="manySocial">
                <a href="https://www.facebook.com/unflibrary" >
                      <img width="30" height="30" alt="Facebook" src="https://libapps.s3.amazonaws.com/accounts/255446/images/Facebook.png" />
                 </a>
                    
                 <a href="https://twitter.com/unflibrary" >
                    <img width="30" height="30" alt="Twitter" src="https://libapps.s3.amazonaws.com/accounts/255446/images/Twitter_Logo2.png" />
                </a>
            
                <a href="https://www.instagram.com/unflibrary/" >
                    <img width="30" height="30" alt="Instagram" src="https://www.unf.edu/uploadedImages/images/graphics/instagram.png?n=5645" />
                </a>

                <a href="https://www.youtube.com/unflibrary/" >
                    <img width="30" alt="Youtube" src="https://libapps.s3.amazonaws.com/accounts/255446/images/youtube_social.png" />
                </a></div><br>
                <a href="https://libguides.unf.edu/giving" >
                    <img src="https://www.unf.edu/uploadedImages/academic/library/GiveToLibraryButtonV2.png" alt="Give to the Library button" />
                </a>
             </div>
        </div>
        <div class="colDivFlat" id="bottomColDivFlat"></div>
        <div id="bottomBox">
            <p><a href="https://www.unf.edu/contact/">Contact</a>  |  <a href="https://www.unf.edu/emergency/">Emergency</a>  |   <a href="https://www.unf.edu/privacy/">Privacy</a>  |   <a href="https://www.unf.edu/president/policies_regulations/">Regulations</a>  |   <a href="https://www.unf.edu/consumer_information/">Consumer Information</a>  |   <a href="https://www.unf.edu/info/accessibility/">Disability Accommodations</a>  |  <a href="https://www.unf.edu/diversity/campus-resources/">Diversity</a>  |  <a href="https://www.unfjobs.org/">Jobs at UNF</a></p>
            <p>If you are experiencing difficulty accessing information on the site due to a disability, visit our <a href="https://www.unf.edu/webaccessibility/" title="Website accessibility at UNF">website accessibility page.</a></p></div>            
            <br>
            <p>Powered by Omeka<br>Original theme created by University of Michigan<br>Altered theme by Lucas Graeff</p>

        </div>
        
    </div>     
<?php fire_plugin_hook('public_footer', array('view'=>$this)); ?>
	</footer>
 
        <script id="twitter-wjs" type="text/javascript" async defer src="//platform.twitter.com/widgets.js"></script>

        <script type="text/javascript">
    var _gaq = _gaq || [];
        _gaq.push(['_setAccount', 'UA-1341620-8']);
        _gaq.push (['_gat._anonymizeIp']);        
        _gaq.push(['_trackPageview']);

    (function() {
         var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
             ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
         var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
         })();
  </script>

</body>
</html>
